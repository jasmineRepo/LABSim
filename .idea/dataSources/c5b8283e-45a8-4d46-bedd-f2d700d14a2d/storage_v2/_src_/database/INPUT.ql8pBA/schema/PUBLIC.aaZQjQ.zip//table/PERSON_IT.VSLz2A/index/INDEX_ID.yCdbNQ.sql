create index INDEX_ID
    on PERSON_IT (ID);

